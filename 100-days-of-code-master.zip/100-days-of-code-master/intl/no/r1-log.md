# #100DaysOfCode Logg - Runde 1 - [Ditt navn her]

Loggen til min #100DaysOfCode-utfordring. Startet [16 juli, mandag, 2017].

## Logg

### **R1D1 (runde 1, dag 1)**

Begynte å lage en værapp. Jobbet med skisser til hvordan appen skal se ut. Hadde det vanskelig med OpenWeather API http://www.example.com

### **R1D2**
