# 100 Days Of Code - Logg

## Dag 0: 26 februar, 2016 (Eksempel 1)

**Dagens fremgang**: Fikset CSS, jobbet med canvas-funksjonalitet for appen.

**Tanker:** Jeg slet virkelig med CSS, men alt-i-alt føler jeg at jeg sakte blir bedre. Canvas er fortsatt nytt for meg, men jeg klarte å finne ut av de basise funksjonalitetene.

**Link(er) til hva jeg har gjort:** [Kalkulatorapp](http://www.example.com)

## Dag 1: 27 februar, 2016 (Eksempel 2)

**Dagens fremgang**: Fikset CSS, jobbet med canvas-funksjonalitet for appen.

**Tanker:** Jeg slet virkelig med CSS, men alt-i-alt føler jeg at jeg sakte blir bedre. Canvas er fortsatt nytt for meg, men jeg klarte å finne ut av de basise funksjonalitetene.

**Link(er) til hva jeg har gjort:** [Kalkulatorapp](http://www.example.com)