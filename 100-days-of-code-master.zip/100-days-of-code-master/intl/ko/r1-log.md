# #100DaysOfCode (#100일코딩) 로그(Log) - 1라운드 - [당신의 이름]

#100DaysOfCode (#100일코딩) 도전에 대한 로그 기록. [2017년 7월 17일, 월요일] 시작함.

## 로그(Log)

### R1D1 
날씨 앱을 만들기 시작했다. 앱의 레이아웃 초안을 작업하고, OpenWeather API http://www.example.com 와 씨름하고 있다.

### R1D2
