# #100DaysOfCode Log - Round 1 - [Seu nome aqui]

O log do meu desafio #100DaysOfCode. Iniciado em [17 de julho, segunda-feira, 2017].

## Log

### R1D1 

Iniciei um app de previsão do tempo. Trabalhei no rascunho do layout e tive dificuldades com a API OpenWeather http://www.example.com

### R1D2
