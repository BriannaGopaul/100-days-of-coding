# 100 Days Of Code - Log

### Dia 0: 29 de fevereiro, 2016 (Exemplo 1)
##### (me delete ou transforme em comentário)

**Progresso do dia:** Consertei CSS, trabalhei na funcionalidade canvas para o app.

**Aprendizados:** Eu realmente apanhei do CSS, mas sinto que estou progredindo e melhorando a cada dia. Canvas ainda é novo para mim, mas eu consegui compreender suas funcionalidades básicas..

**Link do trabalho:** [App de calculadora](http://www.example.com)

### Dia 1: 30 de fevereiro, 2016 (Exemplo 2)
##### (me delete ou transforme em comentário)

**Progresso do dia:** Consertei CSS, trabalhei na funcionalidade canvas para o app.

**Aprendizados:** Eu realmente apanhei do CSS, mas sinto que estou progredindo e melhorando a cada dia. Canvas ainda é novo para mim, mas eu consegui compreender suas funcionalidades básicas..

**Link do trabalho:** [App de calculadora](http://www.example.com)

### Day 2: 1 de março, 2016 (Exemplo 2)

**Progresso do dia:** Eu avancei em alguns exercícios do FreeCodeCamp.

**Aprendizados:** Comecei a programar recentemente e me dá um sentimento muito bom quando consigo resolver um algoritmo que me desafiou durante horas.

**Link(s) do(s) trabalho(s)**
1. [Find the Longest Word in a String](https://www.freecodecamp.com/challenges/find-the-longest-word-in-a-string)
2. [Title Case a Sentence](https://www.freecodecamp.com/challenges/title-case-a-sentence)
