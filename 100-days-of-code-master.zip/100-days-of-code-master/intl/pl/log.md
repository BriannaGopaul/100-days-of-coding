# 100 Days Of Code - Log

### Dzień 0:  22 Stycznia 2018 (Przykład 1)
##### (usuń to lub skomentuj)

**Dzisiejszy Progres**: Naprawiłem/am CSS, pracowałem/am nad implementacją canvasu do apki.

**Przemyślenia:** Miałem/am sporo problemów z CSS, but, overall, Ale generalnie, czuję że rozumiem coraz więcej. Canvas jest dla mnie czymś kompletnie nowym ale udało mi się wprowadzić podstawowe funkcję.

**Linki** [Kalkulator Aplikacja](http://www.example.com)

### Dzień 0: 22 Stycznia 2018 (Przykład 2)
##### (usuń to lub skomentuj)

**Dzisiejszy Progres**: Naprawiłem/am CSS, pracowałem/am nad implementacją canvasu do apki.

**Przemyślenia**: Miałem/am sporo problemów z CSS, but, overall, Ale generalnie, czuję że rozumiem coraz więcej. Canvas jest dla mnie czymś kompletnie nowym ale udało mi się wprowadzić podstawowe funkcję.

**Linki**: [Kalkulator Aplikacja](http://www.example.com)


### Dzień 1: 22 Stycznia, Poniedziałek 

**Dzisiejszy Progres**: Ukończyłem kilka zadań na FreeCodeCamp.

**Przemyślenia** Dopiero co zaczynam programowanie, uczucie ukończenia czegoś i rozwiązania problemu jest super, zwłaszcza po wielu nieudanych próbach.

**Linki**
1. [Find the Longest Word in a String](https://www.freecodecamp.com/challenges/find-the-longest-word-in-a-string)
2. [Title Case a Sentence](https://www.freecodecamp.com/challenges/title-case-a-sentence)
