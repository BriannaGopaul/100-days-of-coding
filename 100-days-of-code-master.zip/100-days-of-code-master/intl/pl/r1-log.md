# #100DaysOfCode Log - Runda 1 - [Twoje Imię Tutaj]

Rozpoczynam wyzwanie #100DaysOfCode w dniu [1 Stycznia 2018].

## Log

### R1D1
Zacząłem/am pracować nad aplikacją pogodową. Zrobiłem/am plany oraz skecze UI/UX. Miałem/am problemy z OpenWeather API http://www.example.com

### R1D2
