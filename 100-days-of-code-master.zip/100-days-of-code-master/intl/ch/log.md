# 100 Days Of Code - 日志

### 第0天: 2016年2月28日 (例子 1)
##### (删除我或注释掉我)

**今天的进展：** 修改了css，为app的canvas的功能进行了工作。

**思考：** 被css困住了一些，但总体来说，我感觉自己在这方面在慢慢进步。Canvas对我来说还是很新，但我明白了一些基本的功能。

**工作成果链接：** [计算器 app](http://www.example.com)

### 第0天: 2016年2月28日 (例子 2)
##### (删除我或注释掉我)

**今天的进展：** 修改了css，为app的canvas的功能进行工作。

**思考：** 被css困住了一些，但总体来说，我感觉自己在这方面在慢慢进步。Canvas对我来说还是很新，但我明白了一些基本的功能。

**工作成果链接：** [计算器 app](http://www.example.com)


### 第二天: 6月27日, 星期一

**今天的进展：** 我完成了FreeCodeCamp上的练习。

**思考：** 我刚开始学习代码，最终在多次尝试和几个小时以后，解诀了算法挑战，这个感觉真不错。

**工作成果链接：**
1. [找到一个String中最长的单词](https://www.freecodecamp.com/challenges/find-the-longest-word-in-a-string)
2. [把一个句子变成标题](https://www.freecodecamp.com/challenges/title-case-a-sentence)
