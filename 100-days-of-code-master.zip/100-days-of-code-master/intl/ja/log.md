# 100 Days Of Code - 学習ログ

### 0日目: 2016年2月28日

**今日の進捗**: 計算機アプリのCSSを修正して、canvasの機能に取り掛かった。

**思ったこと** CSSにはとても苦労したけど、少しずつ上達してきてる気がする。Canvasはまだ始めたばっかりだけど、基本的な機能はいくつか理解できてきた。

**リンク** [計算機アプリ](http://www.example.com)

### 1日目: 2016年6月27日（月）

**今日の進捗**: FreeCodeCampの演習をたくさん進めた。

**思ったこと** プログラミングを始めたばかりだから、何時間もかけてやっとアルゴリズムのチャレンジが解けるとめちゃくちゃ気持ちいい！

**リンク**
1. [Find the Longest Word in a String](https://www.freecodecamp.com/challenges/find-the-longest-word-in-a-string)
2. [Title Case a Sentence](https://www.freecodecamp.com/challenges/title-case-a-sentence)
